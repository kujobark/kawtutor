export const safetyResponses = {
  blocked: "I can’t help with that request."
};
