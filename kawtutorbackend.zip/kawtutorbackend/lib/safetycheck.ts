export default function safetyCheck(input: string) {
  return { safe: true };
}
